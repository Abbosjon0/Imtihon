const elMain = document.querySelector(".main")

elMain